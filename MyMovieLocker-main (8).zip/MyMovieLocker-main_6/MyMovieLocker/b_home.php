<!DOCTYPE html>
<html>

<head>
	<title>MyMovieLocker</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>


<body>
	<header>
		<?php include_once 'incFiles/b_navigation.php'; ?>
	</header>