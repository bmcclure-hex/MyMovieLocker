<!DOCTYPE html>
<html>

<head>
	<title>MyMovieLocker</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>


<body>
	<header>
		<nav class="navbar">
			<!-- LOGO -->
			<a href="index.php">
				<div class="logo">MyMovieLocker</div>
			</a>

			<!-- NAVIGATION MENU -->
			<ul class="nav-links">

				<!-- NAVIGATION MENUS -->
				<div class="menu">
					<li><a href="home.php">Home</a></li>
					<li><a href="b_movies.php">Movies</a></li>
					<li><a href="FAQ.php">FAQ</a></li>
					<li><a href="contact.php">Contact</a></li>
					<li><a href="login.php">Login</a></li>
				</div>
			</ul>
		</nav>
	</header>