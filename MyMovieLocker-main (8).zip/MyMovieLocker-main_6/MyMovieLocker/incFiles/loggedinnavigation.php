<nav class="navbar">
	<!-- LOGO -->
	<a href="myaccount.php">
		<div class="logo">MyMovieLocker</div>
	</a>

	    <!-- NAVIGATION MENU -->
	    <ul class="nav-links">

		    <!-- NAVIGATION MENUS -->
		    <div class="menu">
			<li><a href="myaccount.php">My Account</a></li>
			<li><a href="movies.php">Movies</a></li>
			<li><a href="locker.php">Locker</a></li>
			<li><a href="login.php?logout=true">Logout</a></li>
			<li><a href="faq.php">FAQ</a></li>
			<li><a href="contact.php">Contact</a></li>
		</div>
		    </ul>
	 
</nav>