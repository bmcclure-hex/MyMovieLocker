<footer> <br>
	<p style="text-align:center;">&copy; 2023 MyMovieLocker. All rights reserved.</p>
</footer>